#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// HC-SR04
#define TRIG_PIN 5
#define ECHO_PIN 18

// LED
#define LED_MERAH 12
#define LED_KUNING 13
#define LED_BIRU 14

// LCD I2C
LiquidCrystal_I2C lcd(0x27, 16, 2);

long duration;
float distance;

void setup() {

  Serial.begin(115200);

  // SDA = GPIO 8
  // SCL = GPIO 9
  Wire.begin(8, 9);

  // Ultrasonic
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // LED
  pinMode(LED_MERAH, OUTPUT);
  pinMode(LED_KUNING, OUTPUT);
  pinMode(LED_BIRU, OUTPUT);

  // LCD
  lcd.init();
  lcd.backlight();

  lcd.setCursor(0,0);
  lcd.print("SAFE-TinyRust");

  delay(2000);
  lcd.clear();
}

void loop() {

  // Trigger HC-SR04
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  // Read Echo
  duration = pulseIn(ECHO_PIN, HIGH);

  // Convert to cm
  distance = duration * 0.034 / 2;

  // Serial Monitor
  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  // LCD
  lcd.clear();

  lcd.setCursor(0,0);
  lcd.print("Distance:");

  lcd.setCursor(0,1);
  lcd.print(distance);
  lcd.print("cm");

  // Kondisi LED
  if(distance > 50){

    // Aman
    digitalWrite(LED_BIRU, HIGH);
    digitalWrite(LED_KUNING, LOW);
    digitalWrite(LED_MERAH, LOW);

    lcd.setCursor(10,1);
    lcd.print("SAFE");
  }

  else if(distance >= 20 && distance <= 50){

    // Waspada
    digitalWrite(LED_BIRU, LOW);
    digitalWrite(LED_KUNING, HIGH);
    digitalWrite(LED_MERAH, LOW);

    lcd.setCursor(7,1);
    lcd.print("ALERT");
  }

  else{

    // Bahaya
    digitalWrite(LED_BIRU, LOW);
    digitalWrite(LED_KUNING, LOW);
    digitalWrite(LED_MERAH, HIGH);

    lcd.setCursor(8,1);
    lcd.print("DANGER");
  }

  delay(500);
}